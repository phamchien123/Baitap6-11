﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmQLSV
{
    internal class SinhVien
    {
        public string MASV {  get; set; }
        public string HOTEN { get; set; }
        public string DIACHI { get; set; }
        public string EMAIL { get; set; }
        public decimal DIENTHOAI {  get; set; }
        public string KHOA { get; set; }
    }
}
