﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace frmQLSV
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát chương trình ", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
            {
                e.Cancel = true;
            }
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QLSVien"].ConnectionString.ToString();
            con = new SqlConnection(conString);
            con.Open();
            Hienthi();
        }
        public void Hienthi()
        {
            string sqlSELECT = "SELECT * FROM Bangsv";
            SqlCommand cmd = new SqlCommand(sqlSELECT, con);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            danhsachsv.DataSource = dt;
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            string sqlINSERT = "INSERT INTO Bangsv (MaSV, Hoten, Diachi, Email, DT, Khoa) " +
                       "VALUES (@MaSV, @Hoten, @Diachi, @Email, @DT, @Khoa)";
            SqlCommand cmd = new SqlCommand( sqlINSERT, con);
            cmd.Parameters.AddWithValue("@MaSV", txbmasv.Text);
            cmd.Parameters.AddWithValue("@Hoten", txbhoten.Text);
            cmd.Parameters.AddWithValue("@Diachi", txbdiachi.Text);
            cmd.Parameters.AddWithValue("@Email", txbemail.Text);
            cmd.Parameters.AddWithValue("@DT", txbdienthoai.Text);
            cmd.Parameters.AddWithValue("@Khoa", txbkhoa.Text);
            cmd.ExecuteNonQuery();
            Hienthi();
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            string sqlEdit = "UPDATE Bangsv SET Hoten=@Hoten,Diachi=@Diachi,Email=@Email,DT=@DT,Khoa=@Khoa WHERE MaSV=@MaSV";
            SqlCommand cmd = new SqlCommand(sqlEdit, con);
            cmd.Parameters.AddWithValue("@MaSV", txbmasv.Text);
            cmd.Parameters.AddWithValue("@Hoten", txbhoten.Text);
            cmd.Parameters.AddWithValue("@Diachi", txbdiachi.Text);
            cmd.Parameters.AddWithValue("@Email", txbemail.Text);
            cmd.Parameters.AddWithValue("@DT", txbdienthoai.Text);
            cmd.Parameters.AddWithValue("@Khoa", txbkhoa.Text);
            cmd.ExecuteNonQuery();
            Hienthi();
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            string sqlDelete = "DELETE FROM Bangsv WHERE MaSV=@MaSV";
            SqlCommand cmd = new SqlCommand(sqlDelete, con);
            cmd.Parameters.AddWithValue("@MaSV", txbmasv.Text);
            cmd.Parameters.AddWithValue("@Hoten", txbhoten.Text);
            cmd.Parameters.AddWithValue("@Diachi", txbdiachi.Text);
            cmd.Parameters.AddWithValue("@Email", txbemail.Text);
            cmd.Parameters.AddWithValue("@DT", txbdienthoai.Text);
            cmd.Parameters.AddWithValue("@Khoa", txbkhoa.Text);
            cmd.ExecuteNonQuery();
            Hienthi();
        }

        private void btntim_Click(object sender, EventArgs e)
        {
            string sqlTimkiem= "SELECT *FROM Bangsv WHERE MaSV=@MaSV";
            SqlCommand cmd = new SqlCommand(sqlTimkiem , con);
            cmd.Parameters.AddWithValue("@MaSV", txbtimkiem.Text);
            cmd.Parameters.AddWithValue("@Hoten", txbhoten.Text);
            cmd.Parameters.AddWithValue("@Diachi", txbdiachi.Text);
            cmd.Parameters.AddWithValue("@Email", txbemail.Text);
            cmd.Parameters.AddWithValue("@DT", txbdienthoai.Text);
            cmd.Parameters.AddWithValue("@Khoa", txbkhoa.Text);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            danhsachsv.DataSource = dt;
        }
    }
}
